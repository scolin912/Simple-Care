package com.simplecare.slidingmenu;
import java.text.DecimalFormat;

import android.app.Activity;
import android.graphics.Point;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;







public class IndoorLocation extends Activity{

	  
	  private SurfaceView sfv;
	  private SurfaceHolder sfh;


	  private Point greenXY = new Point(0, -13);						
	  private Point blueXY = new Point(-8, 13);
	  private Point purpleXY = new Point(8, 13);
	  public static Point[] beacons;
	  private int beaconsNum =3 ;								

	
	  static double locationX = 0;	
	  static double locationY = 0;
	  
	  private void init(){
		  beacons = new Point[beaconsNum];
		  beacons[0] = greenXY;
		  beacons[1] = blueXY;
		  beacons[2] = purpleXY;
		  

	  }
	  
	  @Override
	  protected void onCreate(Bundle savedInstanceState) {
		  init();
		  super.onCreate(savedInstanceState);
	    
		 
		  setContentView(R.layout.indoorsurfaceview);


		  sfv = (SurfaceView) findViewById(R.id.surfaceView1);
		  sfh = sfv.getHolder();
		  sfh.addCallback(new MySfvCallback(IndoorLocation.this));


		  
		  double xypoint[] = getMeetingPoints(4.0, 4.0, 9.0, 7.0, 9.0, 1.0, 0.0025, 1.42, 6.96);
			 
		  locationX = xypoint[0];
		  locationY = -xypoint[1];//??�為y??�相??��?�好?��?��??��??

	  }


	  double norm (double x,double y) // get the norm of a vector
	  {
	      return (float) Math.pow(Math.pow(x,2)+Math.pow(y,2),0.5);
	  }
	  
	  private double[] getMeetingPoints(double x1, double y1, double x2, double y2, double x3, double y3, double r1, double r2, double r3)
	  {

		  double p2p1Distance = (Math.pow(Math.pow(x2-x1,2) + Math.pow(y2-y1,2),0.5)); 

		  
		  double ex[] = {(x2-x1)/p2p1Distance, (y2-y1)/p2p1Distance};

		  double aux[] = {x3-x1,y3-y1}; 
	      
	      //signed magnitude of the x component
		  double i = ex[0] * aux[0] + ex[1] * aux[1]; 

		
		  double aux2[] = { x3-x1-i*ex[0], y3-y1-i*ex[1]};
		  
		    DecimalFormat df = new DecimalFormat("##.000");//??�捨五入小數點第三�??
		    double d1 = Double.parseDouble(df.format(aux2[0]));
		    double d2 = Double.parseDouble(df.format(aux2[1]));
		    

			double ey[] = { d1 / norm (d1,d2), d2 / norm (d1,d2) };
	      //the signed magnitude of the y component
		    DecimalFormat df1 = new DecimalFormat("##.000");
		    double d11 = Double.parseDouble(df1.format(ey[0]));
		    double d21 = Double.parseDouble(df1.format(ey[1]));
			 
		  
		  

		  
		 
		    double j = d11 * d1 + d21 * d2;
		    DecimalFormat jj = new DecimalFormat("##.000");
		    double jj1 = Double.parseDouble(jj.format(j));


		  double x = ((Math.pow(r1,2) - Math.pow(r2,2) + Math.pow(p2p1Distance,2))/ (2 * p2p1Distance));
		  DecimalFormat xx = new DecimalFormat("##.000");
		  double xx1 = Double.parseDouble(xx.format(x));
		  
		  
		  double y = ((Math.pow(r1,2) - Math.pow(r3,2) + Math.pow(i,2) + Math.pow(jj1,2))/((2*jj1) - (i*x/jj1)));
		  DecimalFormat yy = new DecimalFormat("##.000");
		  double yy1 = Double.parseDouble(yy.format(y));
		  


		 
		  double finalXY[] = {x1+ x*ex[0] + y*d11, y1+ x*ex[1] + y*d21};
		  
		  DecimalFormat xy = new DecimalFormat("##.000");
		  double xy1 = Double.parseDouble(xy.format(finalXY[0]));
		  double xy2 = Double.parseDouble(xy.format(finalXY[1]));
		  
		  double finalXY_return[]={xy1,xy2};
		    

	      return finalXY_return;

	  }
	
	

}

package com.simplecare.slidingmenu;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;



public class SecurityFeature extends Activity implements OnClickListener {
	MqttAndroidClient client;
	String topicArm = "";
	String topicDisArm = "";
	
	static String MQTTHOST = "tcp://192.168.1.73:1883";
	static String USERNAME = "sco";//can't used null
	static String PASSWORD = "123";
	
	SharedPreferences sh;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.security_feature);
		
		sh=getSharedPreferences("login text", MODE_PRIVATE);
		String email=sh.getString("loginemail", null);
		
		topicArm = "/arm"+email; //�N�o��email�U�����D������arm
		topicDisArm = "/disarm"+email;//�N�o��email�U�����D������disarm
		
	       String clientId = MqttClient.generateClientId();
	        client =
	        new MqttAndroidClient(this.getApplicationContext(), MQTTHOST,
	                                      clientId);

	        MqttConnectOptions options = new MqttConnectOptions();
	        options.setUserName(USERNAME);
	        options.setPassword(PASSWORD.toCharArray());
	         
	        //IMqttToken token = client.connect(options);
	         
	        try {
	            IMqttToken token = client.connect(options);
	            token.setActionCallback(new IMqttActionListener() {
	                @Override
	                public void onSuccess(IMqttToken asyncActionToken) {
	                    // We are connected
	                	Toast.makeText(SecurityFeature.this,"Connected",Toast.LENGTH_LONG).show();
	               
	                }
	         
	                @Override
	                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
	                    // Something went wrong e.g. connection timeout or firewall problems
	                	Toast.makeText(SecurityFeature.this,"Connection Failed",Toast.LENGTH_LONG).show();
	         
	                }
	            });
	        } catch (MqttException e) {
	            e.printStackTrace();
	        }
	}
	
	public void Arm(View v){
        String topic = topicArm;
        String message = "Armed";
        try {
            client.publish(topic, message.getBytes(),0,false);
        } catch (MqttException e) {
            e.printStackTrace();
        }
	}
	
	public void disArm(View v){
        String topic = topicDisArm;
        String message = "Disarmed";
        try {
            client.publish(topic, message.getBytes(),0,false);
        } catch (MqttException e) {
            e.printStackTrace();
        }
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}

}

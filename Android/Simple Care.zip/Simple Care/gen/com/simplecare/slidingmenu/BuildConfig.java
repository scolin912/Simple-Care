/** Automatically generated file. DO NOT MODIFY */
package com.simplecare.slidingmenu;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}